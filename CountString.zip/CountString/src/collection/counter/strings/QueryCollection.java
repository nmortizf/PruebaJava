package collection.counter.strings;
import java.util.*;


public class QueryCollection {
	
	private List<String> queryCollection = new ArrayList<String>();
	private InputCollection inputCollection;
	private List<Integer> outputCounterCollection = new ArrayList<Integer>();
	private int counter;
	private String stringElement;
	private char control;
	private Scanner input = new Scanner(System.in);
	
	// This method is used to enter the elements to search in the collection
	public void setInputQueryString(){
		do {
			control = 'Y';			
			System.out.println("Please enter an element that you want to look for in the collection:");
			stringElement = input.nextLine();
			queryCollection.add(stringElement);
			System.out.println("Do you want to enter another element for searching? Y/N ");
			control = (input.nextLine().toUpperCase()).charAt(0);			
		}while(control == 'Y');				
	}
	
	// This method prints the Query Collection
	public void showQueryCollection() {	
		System.out.println("The Query Collection is:");
		System.out.print("[");
		for(String element : queryCollection ) {
			System.out.print(element + " ");			
		}
		System.out.println("]");
	}
	
	// This method calculates the number of times that the item that is queried is in the initial collection
	public List<Integer> getCounterCollection(InputCollection newInput){
		this.inputCollection = newInput;
		if( inputCollection == null) {
			System.out.println("There is not a collection where to query items!");
		}
		else if(inputCollection.getInputCollection().size() > 0 && this.queryCollection.size() > 0) {
			for(String queryItem : queryCollection) {
				counter = 0;
				for(String collection : inputCollection.getInputCollection()) {
					if(collection.equals(queryItem)) {
						counter = counter + 1;
					}
				}
				outputCounterCollection.add(counter);
			}
		}
		else {
			System.out.println("There are not items in the Query Collections to look for");
		}		
		return outputCounterCollection;
	}
	
	// This method prints the output in a collection with numbers
	public void showOutputCollection() {
		if (outputCounterCollection.size() <= 0) {
			System.out.println("There is not initial collection and/or collection for being queried!");
		}
		else {
			System.out.print("The number of times for each element for being searched in the initial collection is: [");
			for(int number : outputCounterCollection) {
				System.out.print(number + " ");
			}
			System.out.print("]");
		}
	}

}
