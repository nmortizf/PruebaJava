package collection.counter.strings;
import java.util.*;


public class InputCollection {
	
	// In this part, it is defined the local variables of the class
	private List<String> inputCollection = new ArrayList<>();
	private String stringElement;
	private char control;
	private Scanner input = new Scanner(System.in);
	
	// This method is used for enter the elements in the collection
	public void setInputCollection(){		
		do {
			control = 'Y';			
			System.out.println("Please enter an element in the collection:");
			stringElement = input.nextLine();
			inputCollection.add(stringElement);
			System.out.println("Do you want to enter another element? Y/N ");
			control = (input.nextLine().toUpperCase()).charAt(0);			
		}while(control == 'Y');		
	}
	
	// This is a getter of the attribute inputCollection
	public List<String> getInputCollection(){
		return inputCollection;
	}
	
	// This method is used for printing the collection that was entered, only invoke it for validation
	public void showCollection() {	
		System.out.println("The Input Collection is:");
		System.out.print("[");
		for(String element : inputCollection ) {
			System.out.print(element + " ");			
		}
		System.out.println("]");
	}
	
}
