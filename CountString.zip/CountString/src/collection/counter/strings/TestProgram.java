package collection.counter.strings;

public class TestProgram {

	public static void main(String[] args) {
		
		InputCollection newCollection = new InputCollection();
		QueryCollection newQueryCollection = new QueryCollection();
		
		// Method to enter the Initial Collection
		newCollection.setInputCollection();		
		
		// Method for enter the strings to look for
		newQueryCollection.setInputQueryString();
				
		// Prints the results of the process
		newQueryCollection.getCounterCollection(newCollection);
		newQueryCollection.showQueryCollection();
		newQueryCollection.showOutputCollection();

	}

}
