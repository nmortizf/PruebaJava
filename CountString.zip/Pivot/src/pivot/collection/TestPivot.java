package pivot.collection;

import java.util.*;

public class TestPivot {

	public static void main(String[] args) {		
		List<Integer> myCollection = new ArrayList<>();
		String message;
		
		myCollection.add(1);
		myCollection.add(2);
	    myCollection.add(7);
		myCollection.add(10);
		myCollection.add(6);
		myCollection.add(8);
		myCollection.add(17);
		myCollection.add(3); 
		
		PivotCollection myPivot = new PivotCollection();		
		myPivot.setCollection(myCollection);
		message = myPivot.findPivotPosition();
		System.out.println(message);
	}
}
