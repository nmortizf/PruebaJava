package pivot.collection;

import java.util.*;

public class PivotCollection {

	private List<Integer> collection = new ArrayList<>();
	private int leftSum;
	private int rightSum;
			
	public void setCollection(List<Integer> testCollection) {
		if(testCollection.size() >= 3) 
			this.collection = testCollection;			
		else {
			this.collection = null;
			System.out.println("The size of the collection is less than 3, insert more numbers and try again!");	
		}
	}
		
	public String findPivotPosition() {	
		if(collection != null) {
			for(int i = 1; i < collection.size(); i++) {
				leftSum = 0;
				rightSum = 0;			
				// Add the numbers to the left of the current position
				for(int j = 0; j < i; j++) {
					leftSum += collection.get(j);
				}
				// Add the numbers to the right
				for(int k = i + 1; k < collection.size(); k++) {
					rightSum += collection.get(k);
				}
				
				if(rightSum == leftSum) {
					return "The position of the Pivot is in the position " +  i;				
				}			
			}		
			return "There is not pivot in the collection";
		}
		else {
			return "The size of the collection is nos enough!";
		}		
	}	
}
