package com.myproducts.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.PathVariable;

import com.myproducts.beans.*;

@Controller
public class ProductDeleteController {
	
	@RequestMapping(method = RequestMethod.DELETE, value="/delete/product/{regdNam}")
	
	@ResponseBody
	public String deleteStudentRecord(@PathVariable("regdNam") String regdNam) {
		System.out.println("In deleteProductRecord");   
		return ProductRegistration.getInstance().deleteProduct(regdNam);
	}
	
}

