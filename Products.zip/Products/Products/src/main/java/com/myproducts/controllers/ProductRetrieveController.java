package com.myproducts.controllers;

import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.myproducts.beans.*;

@Controller
public class ProductRetrieveController {
	
	@RequestMapping(method = RequestMethod.GET, value="/product/allproducts")
	
	@ResponseBody
	public List<Product> getAllProducts(){
		return ProductRegistration.getInstance().getProductRecords();
	}
	
}
