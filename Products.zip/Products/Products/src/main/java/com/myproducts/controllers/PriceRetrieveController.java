package com.myproducts.controllers;

import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.myproducts.beans.*;

@Controller
public class PriceRetrieveController {
	
	@RequestMapping(method = RequestMethod.GET, value="/price/allproducts")
	
	@ResponseBody
	public EconomicAccount getAllProducts(){
		return ProductRegistration.getInstance().getEconomicDetails();
	}	


}
