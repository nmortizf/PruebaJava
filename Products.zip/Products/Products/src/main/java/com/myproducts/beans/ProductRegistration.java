package com.myproducts.beans;

import java.util.*;

public class ProductRegistration {

	private List<Product> productRecords;
	
	private EconomicAccount account;
	private int totalAmount;
	
	// Begin the declaration of a Singleton
	private static ProductRegistration prdregd = null;
	
	private ProductRegistration() {
		productRecords = new ArrayList<Product>();
		account = new EconomicAccount();		
	}
	
	public static ProductRegistration getInstance() {
		if(prdregd == null) {
			prdregd = new ProductRegistration();
			return prdregd;
		}
		else {
			return prdregd;
		}
	}
	// End  of the declaration of a Singleton
	
	public void add(Product prd) {
		productRecords.add(prd);
	}
	
	public String upDateProduct(Product prd) {
		for(int i=0; i<productRecords.size(); i++)
        {
            Product prdn = productRecords.get(i);
            if(prdn.getName().equals(prd.getName())) {
              productRecords.set(i, prd);//update the new record
              return "Update successful";
            }
        }
		return "Update un-successful";
	}
	

	public String deleteProduct(String name) {
		for(int i=0; i<productRecords.size(); i++)
		{
            Product prdn = productRecords.get(i);
            if(prdn.getName().equals(name)){
              productRecords.remove(i);//update the new record
              return "Delete successful";
            }
        }
		return "Delete un-successful";
	}
	
	public List<Product> getProductRecords() {
		    return productRecords;
	}
	
	// method for calculate the total price of the products
	public void calculateTotalPrice() {
		totalAmount = 0;
		account.setBalance(36000);
		for(Product p : productRecords) {
			totalAmount += p.getPrice();
		}
		account.setTotalPrice(totalAmount);
	}
	
	public EconomicAccount getEconomicDetails() {
		calculateTotalPrice();
		return account;
	}
		
}
