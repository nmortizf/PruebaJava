package com.myproducts.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.myproducts.beans.*;

@Controller
public class ProductUpdateController {

	@RequestMapping(method = RequestMethod.PUT, value="/update/product")
	
	@ResponseBody
	public String updateProductRecord(@RequestBody Product prdn) {
		System.out.println("In updateProductRecord");   
		return ProductRegistration.getInstance().upDateProduct(prdn);
	}

}
