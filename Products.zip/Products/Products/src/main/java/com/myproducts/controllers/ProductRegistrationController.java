package com.myproducts.controllers;

import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.myproducts.beans.*;

@Controller
public class ProductRegistrationController {

	@RequestMapping(method = RequestMethod.POST, value="/register/product")
	
	 @ResponseBody
	  public ProductRegistrationReply registerStudent(@RequestBody Product product) {
			
			int balance = ProductRegistration.getInstance().getEconomicDetails().getBalance();
			int totalPrice = ProductRegistration.getInstance().getEconomicDetails().getTotalPrice() + product.getPrice();			
	        ProductRegistrationReply prdregreply = new ProductRegistrationReply(); 
			if(balance >= totalPrice) {	
				System.out.println("In registerProduct");
		        ProductRegistration.getInstance().add(product);	        
		        prdregreply.setName(product.getName());
		        prdregreply.setPrice(product.getPrice());
		        prdregreply.setDateOfExpiration(product.getDateOfExpiration());
		        prdregreply.setDatePublished(product.getDatePublished());
		        prdregreply.setRegistrationStatus("Successful");
			}
			else {				
		        prdregreply.setRegistrationStatus("There is not enough money for this transaction!");
			}				
	        return prdregreply;
	}	
		
}
